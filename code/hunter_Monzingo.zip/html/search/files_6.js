var searchData=
[
  ['page_2ecpp',['Page.cpp',['../_page_8cpp.html',1,'']]],
  ['page_2eh',['Page.h',['../_page_8h.html',1,'']]],
  ['porterstemmer_2eh',['PorterStemmer.h',['../_porter_stemmer_8h.html',1,'']]]
];
