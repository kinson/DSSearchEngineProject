var searchData=
[
  ['userinterface',['UserInterface',['../class_user_interface.html#ae6fb70370701b3bd6120e923df9705b0',1,'UserInterface']]]
];
