var searchData=
[
  ['j',['j',['../structstemmer.html#a024d42a47e06bd5207e2494cbfefbf2f',1,'stemmer']]]
];
