var searchData=
[
  ['userinterface',['UserInterface',['../class_user_interface.html',1,'']]]
];
