var searchData=
[
  ['query',['Query',['../class_query.html#a4c1633236bdb9fa8d3fd3572a469889d',1,'Query']]],
  ['queryprocessor',['QueryProcessor',['../class_query_processor.html#a32a6760ff0aab51b38fb8eb236e2e140',1,'QueryProcessor']]]
];
