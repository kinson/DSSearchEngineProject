var searchData=
[
  ['b',['b',['../structstemmer.html#a0ae99db94786418a0c4d85a2a15382a5',1,'stemmer']]]
];
