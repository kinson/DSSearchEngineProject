var searchData=
[
  ['k',['k',['../structstemmer.html#a587d5f8fd5c491688bc91e7d3b5e262e',1,'stemmer']]]
];
