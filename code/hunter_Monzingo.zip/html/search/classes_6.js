var searchData=
[
  ['query',['Query',['../class_query.html',1,'']]],
  ['queryprocessor',['QueryProcessor',['../class_query_processor.html',1,'']]]
];
