var searchData=
[
  ['within',['within',['../classwithin.html',1,'']]]
];
