var searchData=
[
  ['stem',['stem',['../classstemming_1_1stem.html',1,'stemming']]],
  ['stemhelper',['StemHelper',['../class_stem_helper.html',1,'']]],
  ['stemmer',['stemmer',['../structstemmer.html',1,'']]],
  ['string_5ftrim',['string_trim',['../classstring__util_1_1string__trim.html',1,'string_util']]]
];
