var indexSectionsWithContent =
{
  0: "abcdfghijklmnopqrstuw~",
  1: "adhinpqrsu",
  2: "adhimnpqrsu",
  3: "abcdfghilmnopqrsuw~",
  4: "bfjk",
  5: "ah",
  6: "ft"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Friends",
  6: "Macros"
};

