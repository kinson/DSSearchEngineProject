var searchData=
[
  ['clearcollection',['clearCollection',['../class_document_parser.html#adb2c732f67e7442edbc99979a3fc9ba6',1,'DocumentParser']]],
  ['clearindex',['clearIndex',['../class_user_interface.html#ac6235e19919c71faf514f82ae89b922f',1,'UserInterface']]],
  ['clearquery',['clearQuery',['../class_query.html#aa8b2a46725fdad4e06aad405b6c18227',1,'Query']]],
  ['createstructure',['createStructure',['../class_user_interface.html#a6069a7281cd1121e14fd863c9f29d5b9',1,'UserInterface']]]
];
