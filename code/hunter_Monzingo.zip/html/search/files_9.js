var searchData=
[
  ['stemhelper_2eh',['stemHelper.h',['../stem_helper_8h.html',1,'']]]
];
